import React, { useState, useEffect, useRef } from 'react';
import { Plus, Upload, Play, Share2, Trophy, Users, Heart, Zap, Star, X, Check, Camera, Video, MessageSquare } from 'lucide-react';

interface Box {
  id: number;
  claimed: boolean;
  name?: string;
  message?: string;
  image?: string;
  video?: string;
  url?: string;
  color?: string;
  timestamp?: number;
  groupId?: string;
  isGroupLeader?: boolean;
}

interface Creator {
  name: string;
  boxes: number;
  avatar?: string;
}

const App: React.FC = () => {
  const GRID_COLS = 50; // 50 columns
  const GRID_ROWS = 200; // 200 rows = 10,000 boxes total
  const BOX_SIZE = 20; // 20px boxes for better mobile experience
  
  const [boxes, setBoxes] = useState<Box[]>([]);
  const [selectedBoxes, setSelectedBoxes] = useState<number[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [isSelecting, setIsSelecting] = useState(false);
  const [dragStart, setDragStart] = useState<{row: number, col: number} | null>(null);
  const [hoveredBox, setHoveredBox] = useState<number | null>(null);
  const [paymentProcessing, setPaymentProcessing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    message: '',
    url: '',
    image: null as File | null,
    video: null as File | null
  });
  const [uploadType, setUploadType] = useState<'image' | 'video' | 'message'>('message');
  const gridRef = useRef<HTMLDivElement>(null);

  // Initialize boxes with some sample data
  useEffect(() => {
    const initialBoxes: Box[] = [];
    const sampleCreators: Creator[] = [
      { name: 'CryptoKing', boxes: 156, avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop' },
      { name: 'PixelArtist', boxes: 89, avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop' },
      { name: 'TechGuru', boxes: 67, avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop' },
      { name: 'DigitalNomad', boxes: 45, avatar: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop' },
      { name: 'StartupFounder', boxes: 34, avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop' }
    ];
    
    for (let i = 1; i <= GRID_COLS * GRID_ROWS; i++) {
      const isClaimed = Math.random() < 0.08; // 8% claimed
      const creator = sampleCreators[Math.floor(Math.random() * sampleCreators.length)];
      
      initialBoxes.push({
        id: i,
        claimed: isClaimed,
        name: isClaimed ? creator.name : undefined,
        message: isClaimed ? `Box #${i} - ${creator.name}'s space` : undefined,
        url: isClaimed ? `https://example.com/${creator.name.toLowerCase()}` : undefined,
        image: isClaimed && Math.random() > 0.5 ? creator.avatar : undefined,
        color: isClaimed ? `hsl(${Math.random() * 360}, 70%, 60%)` : undefined,
        timestamp: isClaimed ? Date.now() - Math.random() * 86400000 : undefined
      });
    }
    
    setBoxes(initialBoxes);
  }, []);

  const getBoxPosition = (id: number) => {
    const row = Math.floor((id - 1) / GRID_COLS);
    const col = (id - 1) % GRID_COLS;
    return { row, col };
  };

  const getBoxId = (row: number, col: number) => {
    return row * GRID_COLS + col + 1;
  };

  const handleMouseDown = (boxId: number, event: React.MouseEvent) => {
    event.preventDefault();
    const box = boxes.find(b => b.id === boxId);
    if (box?.claimed) return;

    const { row, col } = getBoxPosition(boxId);
    setDragStart({ row, col });
    setIsSelecting(true);
    setSelectedBoxes([boxId]);
  };

  const handleMouseEnter = (boxId: number) => {
    if (!isSelecting || !dragStart) return;

    const { row, col } = getBoxPosition(boxId);
    const minRow = Math.min(dragStart.row, row);
    const maxRow = Math.max(dragStart.row, row);
    const minCol = Math.min(dragStart.col, col);
    const maxCol = Math.max(dragStart.col, col);

    const newSelection: number[] = [];
    for (let r = minRow; r <= maxRow; r++) {
      for (let c = minCol; c <= maxCol; c++) {
        const id = getBoxId(r, c);
        const box = boxes.find(b => b.id === id);
        if (box && !box.claimed) {
          newSelection.push(id);
        }
      }
    }
    setSelectedBoxes(newSelection);
  };

  const handleMouseUp = () => {
    setIsSelecting(false);
    setDragStart(null);
  };

  const handleBoxClick = (boxId: number) => {
    const box = boxes.find(b => b.id === boxId);
    
    // If box is claimed and has URL, open it
    if (box?.claimed && box.url) {
      window.open(box.url, '_blank');
      return;
    }
    
    // If box is not claimed, allow selection
    if (!box?.claimed && !isSelecting) {
      setSelectedBoxes([boxId]);
      setShowModal(true);
    }
  };

  const getBoxContent = (box: Box) => {
    // If this box is part of a group, show the content spanning across all group boxes
    if (box.groupId && (box.image || box.video)) {
      const groupBoxes = boxes.filter(b => b.groupId === box.groupId).sort((a, b) => a.id - b.id);
      const isFirstBox = box.id === groupBoxes[0]?.id;
      
      if (isFirstBox && groupBoxes.length > 1) {
        // Calculate dimensions for spanning content
        const positions = groupBoxes.map(b => getBoxPosition(b.id));
        const minRow = Math.min(...positions.map(p => p.row));
        const maxRow = Math.max(...positions.map(p => p.row));
        const minCol = Math.min(...positions.map(p => p.col));
        const maxCol = Math.max(...positions.map(p => p.col));
        
        const spanWidth = (maxCol - minCol + 1) * BOX_SIZE + (maxCol - minCol);
        const spanHeight = (maxRow - minRow + 1) * BOX_SIZE + (maxRow - minRow);
        
        if (box.image) {
          return (
            <img 
              src={box.image} 
              alt={box.name} 
              className="absolute top-0 left-0 object-cover z-10 pointer-events-none"
              style={{ 
                width: `${spanWidth}px`, 
                height: `${spanHeight}px`
              }}
            />
          );
        }
        if (box.video) {
          return (
            <video 
              src={box.video} 
              className="absolute top-0 left-0 object-cover z-10 pointer-events-none" 
              style={{ 
                width: `${spanWidth}px`, 
                height: `${spanHeight}px`
              }}
              muted 
              loop 
              autoPlay 
            />
          );
        }
      } else if (groupBoxes.length > 1) {
        // For non-first boxes in a group, return empty to avoid duplicate content
        return null;
      }
    }
    
    // Single box content
    if (box.image) {
      return <img src={box.image} alt={box.name} className="w-full h-full object-cover" />;
    }
    if (box.video) {
      return <video src={box.video} className="w-full h-full object-cover" muted loop autoPlay />;
    }
    if (box.name) {
      return <span className="text-[8px] font-bold text-center leading-none">{box.name.slice(0, 2)}</span>;
    }
    return null;
  };

  const simulatePayment = async () => {
    setPaymentProcessing(true);
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    setPaymentProcessing(false);
    return true; // Simulate successful payment
  };

  const handlePurchase = async () => {
    if (selectedBoxes.length === 0) return;
    if (!formData.url) return;

    try {
      const paymentSuccess = await simulatePayment();
      
      if (!paymentSuccess) {
        alert('Payment failed. Please try again.');
        return;
      }

      const groupId = selectedBoxes.length > 1 ? `group_${Date.now()}` : undefined;
      const imageUrl = formData.image ? URL.createObjectURL(formData.image) : undefined;
      const videoUrl = formData.video ? URL.createObjectURL(formData.video) : undefined;

      const updatedBoxes = boxes.map(box => {
        if (selectedBoxes.includes(box.id)) {
          return {
            ...box,
            claimed: true,
            name: formData.name,
            message: formData.message,
            url: formData.url,
            image: imageUrl,
            video: videoUrl,
            groupId: groupId,
            color: `hsl(${Math.random() * 360}, 70%, 60%)`,
            timestamp: Date.now()
          };
        }
        return box;
      });

      setBoxes(updatedBoxes);
      setSelectedBoxes([]);
      setShowModal(false);
      setFormData({ name: '', message: '', url: '', image: null, video: null });
      alert('Payment successful! Your content has been posted.');
    } catch (error) {
      alert('An error occurred. Please try again.');
      setPaymentProcessing(false);
    }
  };

  const getBoxStyle = (box: Box) => {
    const isSelected = selectedBoxes.includes(box.id);
    const isHovered = hoveredBox === box.id;
    
    let style: React.CSSProperties = {
      width: `${BOX_SIZE}px`,
      height: `${BOX_SIZE}px`,
      border: '1px solid #e5e7eb',
      cursor: box.claimed ? 'pointer' : 'crosshair',
      transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      position: 'relative',
      overflow: 'hidden',
      borderRadius: '2px'
    };

    if (box.claimed) {
      style.backgroundColor = box.color || '#3b82f6';
      style.color = 'white';
      style.boxShadow = isHovered ? '0 4px 12px rgba(0,0,0,0.3)' : '0 1px 3px rgba(0,0,0,0.1)';
      style.transform = isHovered ? 'scale(1.1)' : 'scale(1)';
      style.zIndex = isHovered ? 10 : 1;
    } else if (isSelected) {
      style.backgroundColor = '#fbbf24';
      style.borderColor = '#f59e0b';
      style.boxShadow = '0 0 0 1px #f59e0b';
      style.transform = 'scale(1.05)';
    } else {
      style.backgroundColor = isHovered ? '#f8fafc' : '#ffffff';
      style.borderColor = isHovered ? '#cbd5e1' : '#e5e7eb';
      style.boxShadow = isHovered ? '0 2px 4px rgba(0,0,0,0.1)' : 'none';
    }

    return style;
  };

  const totalCost = selectedBoxes.length;
  const claimedCount = boxes.filter(b => b.claimed).length;
  const availableCount = boxes.length - claimedCount;

  const isFormValid = formData.name && formData.url && (formData.message || formData.image || formData.video);

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <header className="relative overflow-hidden bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <div className="absolute inset-0 bg-grid-pattern opacity-30"></div>
        <div className="relative max-w-7xl mx-auto px-4 py-12 md:py-20 text-center">
          <div className="animate-float">
            <h1 className="text-4xl md:text-6xl lg:text-8xl font-black text-gray-900 mb-6 leading-tight">
              Own a Piece of the
              <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent animate-gradient">
                {' '}Internet
              </span>
            </h1>
            <p className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-700 mb-4">
              for $1 per Box
            </p>
          </div>
          
          <div className="animate-float-delayed">
            <p className="text-lg md:text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              Upload your image, message, or video and place it forever on the wall.
              <br />
              <span className="font-semibold text-gray-800">Join thousands creating digital history.</span>
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8 md:mb-12">
            <button
              onClick={() => {
                const grid = document.getElementById('pixel-grid');
                grid?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="group relative px-6 md:px-8 py-3 md:py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold text-base md:text-lg rounded-full hover:from-blue-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
            >
              <span className="relative z-10 flex items-center space-x-2">
                <Zap className="w-4 h-4 md:w-5 md:h-5" />
                <span>Get Started</span>
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-pink-600 to-yellow-600 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </button>
            
            <div className="flex items-center space-x-4 md:space-x-6 text-xs md:text-sm text-gray-600">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 md:w-3 md:h-3 bg-green-500 rounded-full animate-pulse"></div>
                <span>{claimedCount.toLocaleString()} claimed</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 md:w-3 md:h-3 bg-gray-400 rounded-full"></div>
                <span>{availableCount.toLocaleString()} available</span>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-8 max-w-4xl mx-auto">
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-4 md:p-6 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="flex items-center justify-center w-10 h-10 md:w-12 md:h-12 bg-blue-100 rounded-full mx-auto mb-4">
                <Users className="w-5 h-5 md:w-6 md:h-6 text-blue-600" />
              </div>
              <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-2">10,000</h3>
              <p className="text-gray-600 text-sm md:text-base">Total Boxes</p>
            </div>
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-4 md:p-6 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="flex items-center justify-center w-10 h-10 md:w-12 md:h-12 bg-green-100 rounded-full mx-auto mb-4">
                <Heart className="w-5 h-5 md:w-6 md:h-6 text-green-600" />
              </div>
              <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-2">${claimedCount}</h3>
              <p className="text-gray-600 text-sm md:text-base">Raised So Far</p>
            </div>
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-4 md:p-6 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="flex items-center justify-center w-10 h-10 md:w-12 md:h-12 bg-purple-100 rounded-full mx-auto mb-4">
                <Star className="w-5 h-5 md:w-6 md:h-6 text-purple-600" />
              </div>
              <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-2">∞</h3>
              <p className="text-gray-600 text-sm md:text-base">Possibilities</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 md:py-12">
        {/* Pixel Grid */}
        <div className="bg-white rounded-2xl shadow-lg p-4 md:p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
            <h2 className="text-xl md:text-2xl font-bold text-gray-900">The Wall</h2>
            {selectedBoxes.length > 0 && (
              <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-4">
                <div className="bg-yellow-100 text-yellow-800 px-3 md:px-4 py-2 rounded-full font-semibold text-sm">
                  {selectedBoxes.length} boxes selected • ${totalCost}
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setShowModal(true)}
                    className="bg-blue-600 text-white px-4 md:px-6 py-2 rounded-full hover:bg-blue-700 transition-colors font-semibold text-sm"
                  >
                    Claim Now
                  </button>
                  <button
                    onClick={() => setSelectedBoxes([])}
                    className="text-gray-500 hover:text-red-500 transition-colors p-2"
                  >
                    <X className="w-4 h-4 md:w-5 md:h-5" />
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="mb-4 text-xs md:text-sm text-gray-600">
            <p className="mb-2">💡 <strong>How to select:</strong> Click and drag to select multiple boxes for your branding</p>
            <div className="flex flex-wrap items-center gap-4 md:gap-6">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 md:w-4 md:h-4 bg-white border border-gray-300 rounded"></div>
                <span>Available</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 md:w-4 md:h-4 bg-blue-500 rounded"></div>
                <span>Claimed</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 md:w-4 md:h-4 bg-yellow-400 rounded"></div>
                <span>Selected</span>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <div 
              id="pixel-grid"
              ref={gridRef}
              className="inline-block overflow-auto max-h-[400px] md:max-h-[600px] p-2 md:p-4 bg-gray-50 rounded-xl"
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
            >
              <div
                className="grid gap-[1px]"
                style={{ 
                  gridTemplateColumns: `repeat(${GRID_COLS}, ${BOX_SIZE}px)`,
                  userSelect: 'none'
                }}
              >
                {boxes.map((box) => (
                  <div
                    key={box.id}
                    style={getBoxStyle(box)}
                    onClick={() => handleBoxClick(box.id)}
                    onMouseDown={(e) => !box.claimed && handleMouseDown(box.id, e)}
                    onMouseEnter={() => {
                      if (!box.claimed) handleMouseEnter(box.id);
                      setHoveredBox(box.id);
                    }}
                    onMouseLeave={() => setHoveredBox(null)}
                  >
                    {box.claimed ? (
                      <div className="w-full h-full flex items-center justify-center relative overflow-hidden">
                        {getBoxContent(box)}
                      </div>
                    ) : (
                      <div className="w-full h-full flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                        <Plus className="w-2 h-2 md:w-3 md:h-3 text-gray-400" />
                      </div>
                    )}

                    {/* Hover Tooltip */}
                    {box.claimed && hoveredBox === box.id && (
                      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-black text-white text-xs rounded-lg px-3 py-2 whitespace-nowrap z-20 shadow-lg max-w-48">
                        <div className="font-semibold">{box.name || 'Anonymous'}</div>
                        {box.message && <div className="opacity-90 truncate">{box.message}</div>}
                        {box.url && <div className="text-blue-300">🔗 Click to visit</div>}
                        <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-black"></div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Purchase Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto animate-modal-in">
            <div className="p-4 md:p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900">
                  Claim {selectedBoxes.length} Box{selectedBoxes.length > 1 ? 'es' : ''}
                </h2>
                <button
                  onClick={() => setShowModal(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="w-5 h-5 md:w-6 md:h-6" />
                </button>
              </div>

              {/* Upload Type Selection */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-3">Content Type</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => setUploadType('message')}
                    className={`p-3 rounded-lg border-2 transition-all ${
                      uploadType === 'message' 
                        ? 'border-blue-500 bg-blue-50 text-blue-700' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <MessageSquare className="w-4 h-4 md:w-5 md:h-5 mx-auto mb-1" />
                    <span className="text-xs font-medium">Message</span>
                  </button>
                  <button
                    onClick={() => setUploadType('image')}
                    className={`p-3 rounded-lg border-2 transition-all ${
                      uploadType === 'image' 
                        ? 'border-blue-500 bg-blue-50 text-blue-700' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <Camera className="w-4 h-4 md:w-5 md:h-5 mx-auto mb-1" />
                    <span className="text-xs font-medium">Image</span>
                  </button>
                  <button
                    onClick={() => setUploadType('video')}
                    className={`p-3 rounded-lg border-2 transition-all ${
                      uploadType === 'video' 
                        ? 'border-blue-500 bg-blue-50 text-blue-700' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <Video className="w-4 h-4 md:w-5 md:h-5 mx-auto mb-1" />
                    <span className="text-xs font-medium">Video</span>
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Name *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    placeholder="Your name or brand"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Website URL *
                  </label>
                  <input
                    type="url"
                    value={formData.url}
                    onChange={(e) => setFormData(prev => ({ ...prev, url: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    placeholder="https://your-website.com"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Message
                  </label>
                  <textarea
                    value={formData.message}
                    onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    rows={3}
                    placeholder="Your message to the world"
                  />
                </div>

                {uploadType === 'image' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Upload Image
                    </label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => setFormData(prev => ({ ...prev, image: e.target.files?.[0] || null }))}
                        className="hidden"
                        id="image-upload"
                      />
                      <label htmlFor="image-upload" className="cursor-pointer">
                        <Camera className="w-6 h-6 md:w-8 md:h-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-sm text-gray-600">
                          {formData.image ? formData.image.name : 'Click to upload image'}
                        </p>
                      </label>
                    </div>
                  </div>
                )}

                {uploadType === 'video' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Upload Video
                    </label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                      <input
                        type="file"
                        accept="video/*"
                        onChange={(e) => setFormData(prev => ({ ...prev, video: e.target.files?.[0] || null }))}
                        className="hidden"
                        id="video-upload"
                      />
                      <label htmlFor="video-upload" className="cursor-pointer">
                        <Video className="w-6 h-6 md:w-8 md:h-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-sm text-gray-600">
                          {formData.video ? formData.video.name : 'Click to upload video'}
                        </p>
                      </label>
                    </div>
                  </div>
                )}

                <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 md:p-6 rounded-xl">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-gray-900">Total Cost:</span>
                    <span className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                      ${totalCost}
                    </span>
                  </div>
                  {selectedBoxes.length > 1 && (
                    <p className="text-sm text-gray-600">
                      💡 Your content will span across all {selectedBoxes.length} selected boxes
                    </p>
                  )}
                  {selectedBoxes.length === 1 && (
                    <p className="text-sm text-gray-600">
                      💡 Your content will show in the selected box
                    </p>
                  )}
                </div>

                <button
                  onClick={handlePurchase}
                  disabled={!isFormValid || paymentProcessing}
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 font-bold text-lg shadow-lg hover:shadow-xl transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                >
                  <span className="flex items-center justify-center space-x-2">
                    {paymentProcessing ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                        <span>Processing Payment...</span>
                      </>
                    ) : (
                      <>
                        <Check className="w-5 h-5" />
                        <span>
                          {!isFormValid 
                            ? 'Fill All Required Fields' 
                            : `Pay $${totalCost} & Claim`
                          }
                        </span>
                      </>
                    )}
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-6 mt-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center text-gray-400">
            <p>&copy; 2024 1 Dollar Wall</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;